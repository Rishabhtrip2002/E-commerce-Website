import React from 'react';
import "./Home.css";
import banner from '../../../../public/img/banner1.png'



const Home = () => {

  return (
    <>

<div className="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
  <div className="offcanvas-header">
    <h5 id="offcanvasRightLabel">Cart</h5>
    <button type="button" className="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div className="offcanvas-body">
  <div className='card p-1'>
  <div className='row '>
    <div className='col-4'>
    <img src="../../../../public/img/product1.png" alt="iPhone 13 Pro" className="img-fluid w-100" />
    </div>
    <div className='col-8 d-flex align-items-center'>
   
  <input type="number" id="quantity" name="quantity" min="1" max="5" defaultValue={1}/>
 
 
    </div>
  </div>

  {/* <div className='row '>
    <div className='col-4'>
    <img src="../../../../public/img/product2.png" alt="iPhone 13 Pro" className="img-fluid w-100" />
    </div>
    <div className='col-8 d-flex align-items-center'>
   
  <input type="number" id="quantity" name="quantity" min="1" max="5" value="1"/>
 
 
    </div>
  </div> */}
 
  </div>

  </div>
</div>
      {/* Section 1: Welcome, Navbar, and Banner */}
       {/* Banner */}
       <div className="bg-body-secondary">
            <div className="row m-0 p-0 py-5">
              <div className="col col-lg-6 col-md-6 col-sm-12 col-12 py-5">
                <div className="px-3 py-5">
                  <h2 className="display-4 fw-bold text3">Electronic Products</h2>
                  <h2 className="display-4 fw-bold text3">Up To <span className="text-warning">50%</span> Off</h2>
                  <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dicta, saepe. <br />
                    Lorem ipsum dolor sit amet consectetur.</p>
                  <a href="#" className="btn rounded-2 fs-6 px-4 btn1">Shop Now</a>
                </div>
              </div>
              <div className="col col-lg-6 col-md-6 col-sm-12 col-12 p-0">
                <div>
                  <img src={banner} alt="Banner" className="img-fluid w-100 h-100" />
                </div>
              </div>
            </div>
          </div>

      {/* Section 2: Product Listing */}
      <section id="product" className="py-5">
        <div className="container">
          <div className="border-bottom border-warning text-center pt-5">
            <h2 className="text-warning text4">PRODUCTS</h2>
          </div>

          {/* Product Cards */}
          <div className="row">
            {/* Product 1: iPhone 13 Pro */}
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 pe-3 pt-4">
              <div className="border rounded-2">
                <img src="../../../../public/img/product1.png" alt="iPhone 13 Pro" className="img-fluid" />
                <div className="text-center">
                  <h4>iPhone 13 Pro</h4>
                  <p>Lorem ipsum dolor sit amet.</p>
                  <p>
                    <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                    <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                    <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                    <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                    <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                  </p>
                </div>
                <div className="row fs-5 px-3">
                  <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-start">
                    <p className="fw-bold">$1000</p>
                  </div>
                  <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-end">
                    {/* <button onClick={() => addToCart('iPhone 13 Pro', 1000)}>
                      <i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i>
                    </button> */}
                    <button  type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"> <i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i></button>
                  </div>
                </div>
              </div>
            </div>
            {/* Repeat similar structure for other products */}
            {/* Airppods */}
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 pe-3 pt-4">
            <div className="border rounded-2">
              <div>
                <img src="../../../../public/img/product2.png" alt="Airpods" className="img-fluid"/>
              </div>
              <div className="text-center">
                <h4>Airpods</h4>
                <p>Lorem ipsum dolor sit amet.</p>
                <p>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                </p>
              </div>
              <div className="row fs-5 px-3">
                <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-start">
                  <div>
                    <p id="Price" className="fw-bold">$100</p>
                  </div>
                </div>
                <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-end">
                  <div>
                    {/* <button onclick="addToCart('product 2', 100)"><i className="fa-solid fa-cart-shopping"
                      style="color: #030303;"></i></button>
                    <a href="cart.html"><i className="fa-solid fa-cart-shopping" style="color: #030303;"></i></a> */}
                    <button  type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"> <i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i></button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* laptop */}
          <div className="col col-lg-3 col-md-6 col-sm-12 col-12 pe-3 pt-4">
            <div className="border rounded-2">
              <div>
                <img src="../../../../public/img/product3.png" alt="Laptop" className="img-fluid"/>
              </div>
              <div className="text-center">
                <h4>Laptop</h4>
                <p>Lorem ipsum dolor sit amet.</p>
                <p>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                </p>
              </div>
              <div className="row fs-5 px-3">
                <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-start">
                  <div>
                    <p id="Price" className="fw-bold">$200</p>
                  </div>
                </div>

                <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-end">
                  <div>
                    {/* <button onclick="addToCart('product 3, 200')"><i className="fa-solid fa-cart-shopping"
                      style="color: #030303;"></i></button>
                    <a href="cart.html"><i className="fa-solid fa-cart-shopping" style="color: #030303;"></i></a> */}
                    <button  type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"> <i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i></button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Ipad */}
          <div className="col col-lg-3 col-md-6 col-sm-12 col-12 pe-3 pt-4">
            <div className="border rounded-2">
              <div>
                <img src="../../../../public/img/product4.png" alt="Ipad" className="img-fluid"/>
              </div>
              <div className="text-center">
                <h4>Ipad</h4>
                <p>Lorem ipsum dolor sit amet.</p>  
                
                <p>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                  <i className="fa-solid fa-star" style={{color: "#FFD43B"}}></i>
                </p>
              </div>
              <div className="row fs-5 px-3">
                <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-start">
                  <div>
                    <p id="Price" className="fw-bold">$300</p>
                  </div>
                </div>
                <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-end">
                  <div>
                    {/* <button onclick="addToCart('product 4', 300)"><i className="fa-solid fa-cart-shopping"
                      style="color: #030303;"></i></button>
                    <a href="cart.html"><i className="fa-solid fa-cart-shopping" style="color: #030303;"></i></a> */}
                    <button  type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"> <i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i></button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div>


          {/* Additional sections and components can be added similarly */}

        </div>
      </section>
      <section>
        {/* Section 3 */}
        <div className="section3">
          <div className="container-fluid p-0">
            <div className="bg-body-secondary">
              <div className="row m-0 p-0 py-5">
                <div className="col col-lg-6 col-md-6 col-sm-12 col-12 py-5">
                  <div className="px-3 py-5">
                    <h2 className="display-4 fw-bold text5">Electronic Products</h2>
                    <h2 className="display-4 fw-bold text5">Up To <span className="text-warning">50%</span> Off</h2>
                    <p className="">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dicta, saepe. <br />
                      Lorem ipsum dolor sit amet consectetur.</p>
                    <a href="#" className="btn rounded-2 fs-6 px-4 btn3">Shop Now</a>
                  </div>
                </div>
                <div className="col col-lg-6 col-md-6 col-sm-12 col-12 p-0">
                  <div>
                    <img src="../../../../public/img/banner2.png" alt="Banner" className="img-fluid w-100 h-100" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Section 4 */}
        <div className="section4 py-5 bg-white">
          <div className="container py-3">

            {/* Products */}
            <div className="row">
              {/* Washing Machine */}
              <div className="col col-lg-3 col-md-6 col-sm-12 col-12 pe-3 pt-4">
                <div className="border rounded-2">
                  <div>
                    <img src="../../../../public/img/pr1.png" alt="Washing Machine" className="img-fluid w-100 h-100" />
                  </div>
                  <div className="text-center">
                    <h4>Washing Machine</h4>
                    <p>Lorem ipsum dolor sit amet.</p>
                    <p>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                    </p>
                  </div>
                  <div className="row fs-5 px-3">
                    <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-start">
                      <div>
                        <p className="fw-bold">$100.50</p>
                      </div>
                    </div>
                    <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-end">
                      <div>
                        <a href="#"><i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* AC */}
              <div className="col col-lg-3 col-md-6 col-sm-12 col-12 pe-3 pt-4">
                <div className="border rounded-2">
                  <div>
                    <img src="../../../../public/img/pr2.png" alt="AC" className="img-fluid w-100 h-100" />
                  </div>
                  <div className="text-center">
                    <h4>AC</h4>
                    <p>Lorem ipsum dolor sit amet.</p>
                    <p>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                    </p>
                  </div>
                  <div className="row fs-5 px-3">
                    <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-start">
                      <div>
                        <p className="fw-bold">$500</p>
                      </div>
                    </div>
                    <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-end">
                      <div>
                        <a href="#"><i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* Microwave Oven */}
              <div className="col col-lg-3 col-md-6 col-sm-12 col-12 pe-3 pt-4">
                <div className="border rounded-2">
                  <div>
                    <img src="../../../../public/img/pr3.png" alt="Microwave Oven" className="img-fluid w-100 h-100" />
                  </div>
                  <div className="text-center">
                    <h4>Microwave Oven</h4>
                    <p>Lorem ipsum dolor sit amet.</p>
                    <p>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                    </p>
                  </div>
                  <div className="row fs-5 px-3">
                    <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-start">
                      <div>
                        <p className="fw-bold">$200.30</p>
                      </div>
                    </div>
                    <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-end">
                      <div>
                        <a href="#"><i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* Fridge */}
              <div className="col col-lg-3 col-md-6 col-sm-12 col-12 pe-3 pt-4">
                <div className="border rounded-2">
                  <div>
                    <img src="../../../../public/img/pr4.png" alt="Fridge" className="img-fluid w-100 h-100" />
                  </div>
                  <div className="text-center">
                    <h4>Fridge</h4>
                    <p>Lorem ipsum dolor sit amet.</p>
                    <p>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                      <i className="fa-solid fa-star" style={{ color: '#FFD43B' }}></i>
                    </p>
                  </div>
                  <div className="row fs-5 px-3">
                    <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-start">
                      <div>
                        <p className="fw-bold">$300</p>
                      </div>
                    </div>
                    <div className="col col-lg-6 col-md-6 col-sm-6 col-6 text-end">
                      <div>
                        <a href="#"><i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="row pb-2 px-3">
              {/* Home Gadgets */}
              <div className="col col-lg-4 col-md-12 col-sm-12 col-12 pe-3 pt-5">
                <div className="p-4 pb-5 b-shad home">
                  <div className="text-light pb-5">
                    <h5 className="fw-bold t-shad1 lettr2">Home Gadget</h5>
                    <h6 className="pb-5 t-shad1 lettr2">Latest collection Up To 50% Off</h6>
                  </div>
                </div>
              </div>
              {/* Gaming Gadgets */}
              <div className="col col-lg-4 col-md-12 col-sm-12 col-12 pe-3 pt-5">
                <div className="p-4 pb-5 b-shad home1">
                  <div className="text-light pb-5">
                    <h5 className="fw-bold t-shad1 lettr2">Gaming Gadget</h5>
                    <h6 className="pb-5 t-shad1 lettr2">Latest collection Up To 50% Off</h6>
                  </div>
                </div>
              </div>
              {/* Accessories */}
              <div className="col col-lg-4 col-md-12 col-sm-12 col-12 pe-3 pt-5">
                <div className="p-4 pb-5 b-shad home2">
                  <div className="text-light pb-5">
                    <h5 className="fw-bold t-shad1 lettr2">Accessories</h5>
                    <h6 className="pb-5 t-shad1 lettr2">Latest collection Up To 50% Off</h6>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Section 5 */}
      <div className="section5 py-4 bg-white">
        <div className="container">
          <div className="row">
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <div className="text-center">
                <p className="fs-2"><i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i></p>
                <h3>Free Shipping</h3>
                <p>On orders over $1000</p>
              </div>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <div className="text-center">
                <p className="fs-2"><i className="fa-solid fa-rotate-left" style={{ color: '#000000' }}></i></p>
                <h3>Free Returns</h3>
                <p>Within 30 days</p>
              </div>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <div className="text-center">
                <p className="fs-2"><i className="fa-solid fa-truck" style={{ color: '#000000' }}></i></p>
                <h3>Fast Delivery</h3>
                <p>Worldwide</p>
              </div>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <div className="text-center">
                <p className="fs-2"><i className="fa-solid fa-thumbs-up" style={{ color: '#000000' }}></i></p>
                <h3>Big Choice</h3>
                <p>Of products</p>
              </div>
            </div>
          </div>
        </div>
      </div>

 

    </>
  );
};

export default Home;
