import React from 'react';
import "./register.css";
import 'bootstrap/dist/css/bootstrap.min.css';


const Register = () => {
    return (
        <div>
          
            {/* Section 2 */}
            <div className="section2 pt-5">
                <div className="container">
                    <div className="rounded-3 b-shad">
                        <div className="text-center my-5 py-5 box1">
                            <h3 className="text-warning my-5 py-5 text3">Register!</h3>
                        </div>
                        <div className="rounded-3 text-center box2">
                            <div className="px-3 py-3">
                                <h3 className="text-warning pt-5 text3">Create Account</h3>
                            </div>
                            <div>
                                <form>
                                    <div className="mb-3">
                                        <input type="text" className="form-control m-auto bg-transparent rounded-0 border-0 border-bottom border-2 border-warning w-75" placeholder="Name" />
                                    </div>
                                    <div className="mb-3">
                                        <input type="text" className="form-control m-auto bg-transparent rounded-0 border-0 border-bottom border-2 border-warning w-75" placeholder="User Name" />
                                    </div>
                                    <div className="mb-3">
                                        <input type="number" className="form-control m-auto bg-transparent rounded-0 border-0 border-bottom border-2 border-warning w-75" placeholder="Phone" />
                                    </div>
                                    <div className="mb-3">
                                        <input type="email" className="form-control m-auto bg-transparent rounded-0 border-0 border-bottom border-2 border-warning w-75" placeholder="Email" />
                                    </div>
                                    <div className="mb-5">
                                        <input type="password" className="form-control m-auto bg-transparent rounded-0 border-0 border-bottom border-2 border-warning w-75" placeholder="Password" />
                                    </div>
                                    <div className="mb-5">
                                        <button type="submit" className="btn btn-warning text-light mb-5">SIGN UP</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Section 3 */}
            <div className="section3 py-5">
                <div className="container py-5">
                    <div className="text-center">
                        <div>
                            <h4 className="py-2 lettr1">Subscribe To The Electronic Shop For Latest upload.</h4>
                        </div>
                        <div>
                            <input type="email" placeholder="Enter Your Email.." className="border-1 border-dark rounded-1 my-2 p-2 email" />
                            <a href="#" className="btn btn-warning rounded-1 text-light ms-2 px-5 py-2 lettr1 t-shad1">SUBSCRIBE</a>
                        </div>
                    </div>
                </div>
            </div>

            {/* Section 4 */}
            <div className="section4 py-5">
                <div className="container">
                    <div className="row">
                        <div className="col col-lg-3 col-md-6 col-sm-12 col-12 px-2">
                            <div className="text-light">
                                <h3 className="text-warning">Electronic Shop</h3>
                                <p className="p1">Karachi <br /> Sindh <br /> Pakistan</p>
                                <p className="p1"><span className="fw-bold">Phone :</span> +91 1234567890</p>
                                <p className="p1"><span className="fw-bold">Email :</span> electronicshop@.com</p>
                            </div>
                        </div>
                        <div className="col col-lg-3 col-md-6 col-sm-12 col-12 px-2">
                            <div>
                                <h5 className="text-warning fw-bold pb-3 pt-2">Useful Links</h5>
                                <ul className="fw-bold p-0">
                                    <li className="pb-3"><a href="index.html" className="fs-6 hovr2">Home</a></li>
                                    <li className="pb-3"><a href="about.html" className="fs-6 hovr2">About Us</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Services</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Terms of Service</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="col col-lg-3 col-md-6 col-sm-12 col-12 px-2">
                            <div>
                                <h5 className="text-warning fw-bold pb-3 pt-2">Our Services</h5>
                                <ul className="fw-bold p-0">
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">PS 5</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Computer</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Gaming Laptop</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Mobile Phone</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Gaming Gadget</a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="col col-lg-3 col-md-6 col-sm-12 col-12 px-2">
                            <div className="text-light">
                                <h5 className="text-warning fw-bold pb-3 pt-2">Our Social Networks</h5>
                                <p className="p1">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quia, quibusdam.</p>
                                <p>
                                    <a href="#" className="btn rounded-5 btn1"><i className="fab fa-twitter" style={{ color: '#ffffff' }}></i></a>
                                    <a href="#" className="btn rounded-5 btn1"><i className="fab fa-facebook-f" style={{ color: '#ffffff' }}></i></a>
                                    <a href="#" className="btn rounded-5 btn1"><i className="fab fa-instagram" style={{ color: '#ffffff' }}></i></a>
                                    <a href="#" className="btn rounded-5 btn1"><i className="fab fa-skype" style={{ color: '#ffffff' }}></i></a>
                                    <a href="#" className="btn rounded-5 btn1"><i className="fab fa-linkedin" style={{ color: '#ffffff' }}></i></a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Section 5 */}
            <div className="section5 pt-5 pb-3">
                <div className="container">
                    <div className="row text-light">
                        <div className="col col-lg-6 col-md-12 col-sm-12 col-12">
                            <div>
                                <p className="p2">© Copyright <span>Electronic Shop</span>. All Rights Reserved.</p>
                            </div>
                        </div>
                        <div className="col col-lg-6 col-md-12 col-sm-12 col-12">
                            <div>
                                <p className="p3">Re-designed by <a href="#" className="text-warning">Vaishnavi Bhutada</a></p>
                            </div>
                            <div>
                                <img src="images/arrow.png" alt="^" className="arrow" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Register;
