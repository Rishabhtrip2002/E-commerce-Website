import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import "./about.css";


const About = () => {
  return (
    <>

      <div className="section2">
        <div className="container">
          <div className="border-bottom text-start pt-5 pb-1">
            <h3 className="text-warning text3">PRODUCT</h3>
          </div>
          <div className="row">
            <div className="col col-lg-12 col-md-12 col-sm-12 col-12">
              <div className="border-bottom border-3 pt-3 pb-1">
                <p>
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ullam odit quae modi cumque, dolorum id
                  quaerat repudiandae tenetur facere veritatis inventore nam sequi. Id ipsam, odio rerum doloremque quam
                  natus perferendis saepe est sapiente optio, ab dolore quaerat temporibus quia non, neque mollitia earum?
                  Ab soluta magnam officiis quasi deleniti, tempora in ex vitae praesentium quaerat facere saepe
                  laudantium temporibus nesciunt recusandae voluptas totam, iste nihil amet et. Fugiat iste eaque provident
                  at omnis. Non asperiores rem fuga id vel ipsum libero corporis? Voluptatem, ullam omnis. Assumenda ipsa
                  sunt sit quidem eligendi reiciendis, deleniti voluptatibus, molestias vel, ab ea quam?
                </p>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col col-lg-5 col-md-5 col-sm-12 col-12 py-5">
              <div className="border rounded">
                <img src="../../../../public/img/banner1.png" alt="Banner" className="img-fluid" />
              </div>
            </div>
            <div className="col col-lg-7 col-md-7 col-sm-12 col-12 py-5">
              <div>
                <p>
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Minima fugit ad impedit libero quis. Ipsam
                  totam accusantium non minima excepturi nemo doloremque, inventore dolores at aperiam voluptates voluptatem
                  maiores odit. Unde dolorum similique facilis veritatis exercitationem excepturi sunt, non at quis
                  deleniti! Mollitia quaerat temporibus reprehenderit neque esse unde minima sed illo, perferendis quidem
                  eum voluptatem ipsam aliquam modi doloremque error. Odit amet veniam necessitatibus quis ad voluptate
                  quidem laudantium, quia vitae quisquam dolorem deleniti temporibus reiciendis, rerum delectus quo
                  cupiditate velit consequuntur neque eum est vero? Perspiciatis architecto provident illo sequi
                  reprehenderit quasi excepturi hic sint perferendis, tempore cupiditate.
                </p>
                <a href="#" className="btn text-light border-1 px-4 btn1">Read More...</a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="section3 py-4">
        <div className="container">
          <div className="row">
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <div className="text-center">
                <p className="fs-2"><i className="fa-solid fa-cart-shopping" style={{ color: '#030303' }}></i></p>
                <h3>Free Shipping</h3>
                <p>On order over $1000</p>
              </div>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <div className="text-center">
                <p className="fs-2"><i className="fa-solid fa-rotate-left" style={{ color: '#000000' }}></i></p>
                <h3>Free Returns</h3>
                <p>Within 30 days</p>
              </div>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <div className="text-center">
                <p className="fs-2"><i className="fa-solid fa-truck" style={{ color: '#000000' }}></i></p>
                <h3>Fast Delivery</h3>
                <p>World Wide</p>
              </div>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <div className="text-center">
                <p className="fs-2"><i className="fa-solid fa-headset" style={{ color: '#000000' }}></i></p>
                <h3>24/7 Support</h3>
                <p>Available</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <footer className="bg-dark text-light p-5">
        <div className="container">
          <div className="row">
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <h5>Information</h5>
              <ul className="list-unstyled">
                <li><a href="#">About Us</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Terms & Conditions</a></li>
                <li><a href="#">Privacy Policy</a></li>
              </ul>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <h5>Customer Service</h5>
              <ul className="list-unstyled">
                <li><a href="#">FAQ</a></li>
                <li><a href="#">Shipping</a></li>
                <li><a href="#">Returns</a></li>
                <li><a href="#">Order Status</a></li>
              </ul>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <h5>My Account</h5>
              <ul className="list-unstyled">
                <li><a href="#">Login</a></li>
                <li><a href="#">Register</a></li>
                <li><a href="#">My Cart</a></li>
                <li><a href="#">Wishlist</a></li>
              </ul>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 py-2">
              <h5>Contact Us</h5>
              <address>
                <ul className="list-unstyled">
                  <li>123, Main Street, New City</li>
                  <li>info@example.com</li>
                  <li>+1234567890</li>
                </ul>
              </address>
            </div>
          </div>
          <div className="row">
            <div className="col text-center py-4">
              <p>&copy; 2024 Electronic Shop. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};

export default About;
