import React from 'react';
import "./contact.css";
import 'bootstrap/dist/css/bootstrap.min.css';

const Contact = () => {
    return (
        <div>
           

            {/* Section 2: Contact Form and Information */}
            <div className="section2 pt-5">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-4 col-md-12 col-sm-12 col-12 py-4">
                            <div className="border rounded p-3 b-shad">
                                <p className="fs-5 fw-bold m-0 p1"><i className="fas fa-phone" style={{ color: '#430056' }}></i> PHONE</p>
                                <p className="fw-bold m-0 p1">+91 0000000000</p>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-12 col-sm-12 col-12 py-4">
                            <div className="border rounded p-3 b-shad">
                                <p className="fs-5 fw-bold m-0 p1"><i className="fas fa-envelope" style={{ color: '#430056' }}></i> EMAIL</p>
                                <p className="fw-bold m-0 p1">example@gmail.com</p>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-12 col-sm-12 col-12 py-4">
                            <div className="border rounded p-3 b-shad">
                                <p className="fs-5 fw-bold m-0 p1"><i className="fas fa-map-marker-alt" style={{ color: '#430056' }}></i> ADDRESS</p>
                                <p className="fw-bold m-0 p1">Karachi Sindh Pakistan</p>
                            </div>
                        </div>
                    </div>
                    <div className="text-center">
                        <form>
                            <div className="row">
                                <div className="col-lg-4 col-md-12 col-sm-12 col-12">
                                    <div className="mb-4">
                                        <input type="text" className="form-control py-2" placeholder="Name" />
                                    </div>
                                </div>
                                <div className="col-lg-4 col-md-12 col-sm-12 col-12">
                                    <div className="mb-4">
                                        <input type="email" className="form-control py-2" placeholder="Email" />
                                    </div>
                                </div>
                                <div className="col-lg-4 col-md-12 col-sm-12 col-12">
                                    <div className="mb-4">
                                        <input type="tel" className="form-control py-2" placeholder="Phone" />
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div className="mb-4">
                                        <textarea className="form-control py-2" placeholder="Message" id="floatingTextarea2" style={{ height: '150px' }}></textarea>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <button type="submit" className="btn rounded-0 fw-bold px-5 py-1 lettr1 btn1">Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            {/* Section 3: Subscription */}
            <div className="section3 py-5">
                <div className="container py-5">
                    <div className="row">
                        <div className="col-lg-12 col-md-12 col-sm-12 col-12">
                            <div className="text-center">
                                <div>
                                    <h4 className="py-2 lettr2">Subscribe To The Electronic Shop For Latest Updates.</h4>
                                </div>
                                <div>
                                    <input type="email" placeholder="Enter Your Email.." className="border-1 border-dark rounded-1 my-2 p-2 email" />
                                    <a href="#" className="btn btn-warning rounded-1 text-light ms-2 px-5 py-2 lettr2 t-shad1">SUBSCRIBE</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Section 4: Footer */}
            <div className="section4 py-5">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 col-md-6 col-sm-12 col-12 px-2">
                            <div className="text-light">
                                <h3 className="text-warning">Electronic Shop</h3>
                                <p className="p2">Karachi <br /> Sindh <br /> Pakistan</p>
                                <p className="p2"><span className="fw-bold">Phone :</span> +91 1234567890</p>
                                <p className="p2"><span className="fw-bold">Email :</span> electronicshop@.com</p>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 col-sm-12 col-12 px-2">
                            <div>
                                <h5 className="text-warning fw-bold pb-3 pt-2">Useful Links</h5>
                                <ul className="fw-bold p-0">
                                    <li className="pb-3"><a href="index.html" className="fs-6 hovr2">Home</a></li>
                                    <li className="pb-3"><a href="about.html" className="fs-6 hovr2">About Us</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Services</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Terms of Service</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 col-sm-12 col-12 px-2">
                            <div>
                                <h5 className="text-warning fw-bold pb-3 pt-2">Our Services</h5>
                                <ul className="fw-bold p-0">
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">PS 5</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Computer</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Gaming Laptop</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Mobile Phone</a></li>
                                    <li className="pb-3"><a href="#" className="fs-6 hovr2">Gaming Gadget</a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 col-sm-12 col-12 px-2">
                            <div className="text-light">
                                <h5 className="text-warning fw-bold pb-3 pt-2">Our Social Networks</h5>
                                <p className="p2">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quia, quibusdam.</p>
                                <p>
                                    <a href="#" className="btn rounded-5 btn2"><i className="fab fa-twitter" style={{ color: '#ffffff' }}></i></a>
                                    <a href="#" className="btn rounded-5 btn2"><i className="fab fa-facebook-f" style={{ color: '#ffffff' }}></i></a>
                                    <a href="#" className="btn rounded-5 btn2"><i className="fab fa-instagram" style={{ color: '#ffffff' }}></i></a>
                                    <a href="#" className="btn rounded-5 btn2"><i className="fab fa-skype" style={{ color: '#ffffff' }}></i></a>
                                    <a href="#" className="btn rounded-5 btn2"><i className="fab fa-linkedin" style={{ color: '#ffffff' }}></i></a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Section 5: Footer */}
            <div className="section5 pt-5 pb-3">
                <div className="container">
                    <div className="row text-light">
                        <div className="col-lg-6 col-md-12 col-sm-12 col-12">
                            <div>
                                <p className="p3">© Copyright <span>Electronic Shop</span>. All Rights Reserved.</p>
                            </div>
                        </div>
                        <div className="col-lg-6 col-md-12 col-sm-12 col-12">
                            <div>
                                <p className="p4">Re-designed by <a href="#" className="text-warning">Vaishnavi Bhutada</a></p>
                            </div>
                            <div>
                                <img src="images/arrow.png" alt="^" className="arrow" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Contact;
