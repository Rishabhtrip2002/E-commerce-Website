import React from 'react'
import "./Pages/home/Home";

const Footer = () => {
  return (
    <>
           {/* Section 6 */}
           <div className="section6 py-5 bg-white">
        <div className="container py-5">
          <div className="row">
            <div className="col col-lg-12 col-md-12 col-sm-12 col-12">
              <div className="text-center">
                <div>
                  <h4 className="py-2 lettr3">Subscribe To The Electronic Shop For Latest uploads.</h4>
                </div>
                <div>
                  <input
                    type="email"
                    placeholder="Enter Your Email.."
                    className="border-1 border-dark rounded-1 my-2 p-2 email"
                  />
                  <button
                    onClick={() => alert('Subscribe clicked')} // Add your subscribe logic here
                    className="btn btn-warning rounded-1 text-light ms-2 px-5 py-2 lettr3 t-shad2"
                  >
                    SUBSCRIBE
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Section 7 */}
      <div className="section7 py-5">
        <div className="container">
          <div className="row">
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 px-2">
              <div className="text-light">
                <h3 className="text-warning">Electronic Shop</h3>
                <p className="p1">Karachi <br /> Sindh <br /> Pakistan</p>
                <p className="p1">
                  <span className="fw-bold">Phone :</span> +91 1234567890
                </p>
                <p className="p1">
                  <span className="fw-bold">Email :</span>{' '}
                  electronicshop@.com
                </p>
              </div>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 px-2">
              <div>
                <h5 className="text-warning fw-bold pb-3 pt-2">Useful Links</h5>
                <ul className="fw-bold p-0">
                  <li className="pb-3">
                    <a href="index.html" className="fs-6 hovr2">
                      Home
                    </a>
                  </li>
                  <li className="pb-3">
                    <a href="about.html" className="fs-6 hovr2">
                      About Us
                    </a>
                  </li>
                  <li className="pb-3">
                    <a href="#" className="fs-6 hovr2">
                      Services
                    </a>
                  </li>
                  <li className="pb-3">
                    <a href="#" className="fs-6 hovr2">
                      Terms of Service
                    </a>
                  </li>
                  <li className="pb-3">
                    <a href="#" className="fs-6 hovr2">
                      Privacy Policy
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 px-2">
              <div>
                <h5 className="text-warning fw-bold pb-3 pt-2">Our Services</h5>
                <ul className="fw-bold p-0">
                  <li className="pb-3">
                    <a href="#" className="fs-6 hovr2">
                      PS 5
                    </a>
                  </li>
                  <li className="pb-3">
                    <a href="#" className="fs-6 hovr2">
                      Computer
                    </a>
                  </li>
                  <li className="pb-3">
                    <a href="#" className="fs-6 hovr2">
                      Gaming Laptop
                    </a>
                  </li>
                  <li className="pb-3">
                    <a href="#" className="fs-6 hovr2">
                      Mobile Phone
                    </a>
                  </li>
                  <li className="pb-3">
                    <a href="#" className="fs-6 hovr2">
                      Gaming Gadget
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col col-lg-3 col-md-6 col-sm-12 col-12 px-2">
              <div className="text-light">
                <h5 className="text-warning fw-bold pb-3 pt-2">
                  Our Social Networks
                </h5>
                <p className="p1">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                  Quia, quibusdam.
                </p>
                <p>
                  <a href="#" className="btn rounded-5 btn4">
                    <i className="fa-brands fa-twitter" style={{ color: '#ffffff' }}></i>
                  </a>
                  <a href="#" className="btn rounded-5 btn4">
                    <i className="fa-brands fa-facebook-f" style={{ color: '#ffffff' }}></i>
                  </a>
                  <a href="#" className="btn rounded-5 btn4">
                    <i className="fa-brands fa-instagram" style={{ color: '#ffffff' }}></i>
                  </a>
                  <a href="#" className="btn rounded-5 btn4">
                    <i className="fa-brands fa-skype" style={{ color: '#ffffff' }}></i>
                  </a>
                  <a href="#" className="btn rounded-5 btn4">
                    <i className="fa-brands fa-linkedin" style={{ color: '#ffffff' }}></i>
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Section 8 */}
      <div className="section8 pt-5 pb-3">
        <div className="container">
          <div className="row text-light">
            <div className="col col-lg-6 col-md-12 col-sm-12 col-12">
              <div>
                <p className="p2">
                  © Copyright <span>Electronic Shop</span>. All Rights Reserved.
                </p>
              </div>
            </div>
            <div className="col col-lg-6 col-md-12 col-sm-12 col-12">
              <div>
                <p className="p3">
                  Re-designed by{' '}
                  <a href="#" className="text-warning">
                    Rishabh Tripathi
                  </a>
                </p>
              </div>
              <div>
                <a href="#" className="back-to-top">
                  <img src="images/arrow.png" alt="^" className="arrow" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default Footer