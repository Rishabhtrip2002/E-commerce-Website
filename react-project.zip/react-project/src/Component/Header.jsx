import React from 'react'
import "./Pages/home/Home";

const Header = () => {
  return (
    <>
        <div className="section1">
        <div className="container-fluid">
          {/* Welcome Line */}
          <div className="row bg-body-light m-0 p-1 pt-3 text1">
            <div className="col col-lg-6 col-md-6 col-sm-6 col-12 m-0 p-0">
              <div className="text-start">
                <p className="fs-5">WELCOME TO OUR SHOP</p>
              </div>
            </div>
            <div className="col col-lg-6 col-md-6 col-sm-6 col-12 m-0 p-0">
              <div className="text-end">
                <a href="/login" className="fs-5 px-2 text2"><i className="fa-solid fa-arrow-right-to-bracket"></i> Login</a>
                <a href="/register" className="fs-5 px-2 text2"><i className="fa-solid fa-arrow-right-to-bracket"></i> Register</a>
              </div>
            </div>
          </div>

          {/* Navbar */}
          <nav className="navbar navbar-expand-lg theme">
            <div className="container-fluid">
              <a className="navbar-brand text-light fs-2 p-2 px-4" href="/">
                <span className="text-warning">E</span>lectronic <span className="text-warning">Shop</span>
              </a>
              <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <ul className="navbar-nav me-auto mb-2 mb-lg-0 fs-6 p-2">
                  <li className="nav-item px-2">
                    <a className="nav-link hovr1" href="/">Home</a>
                  </li>
                  {/* <ul>
                    <li><Link to="/about">About</Link></li>
                    <li><Link to="/contact">Contact</Link></li>
                  </ul> */}
                  <li className="nav-item px-2">
                    <a className="nav-link hovr1" href="#product">Product</a>
                  </li>
                  <li className="nav-item dropdown px-2">
                    <a className="nav-link dropdown-toggle hovr1" href="#" role="button" data-bs-toggle="dropdown"
                      aria-expanded="false">
                      Category
                    </a>
                    <ul className="dropdown-menu theme">
                      <li><a className="dropdown-item hovr1" href="#">Smart Phone</a></li>
                      <li><a className="dropdown-item hovr1" href="#">Mobile Phone</a></li>
                      <li><a className="dropdown-item hovr1" href="#">Cameras</a></li>
                      <li><a className="dropdown-item hovr1" href="#">Fridge</a></li>
                      <li><a className="dropdown-item hovr1" href="#">AC</a></li>
                      <li><a className="dropdown-item hovr1" href="#">Smart Watch</a></li>
                      <li><a className="dropdown-item hovr1" href="#">Headphone</a></li>
                      <li><a className="dropdown-item hovr1" href="#">Laptop</a></li>
                      <li><a className="dropdown-item hovr1" href="#">PC Monitor</a></li>
                    </ul>
                  </li>
                  <li className="nav-item px-2">
                    <a className="nav-link hovr1" href="/about">About</a>
                  </li>
                  <li className="nav-item px-2">
                    <a className="nav-link hovr1" href="/contact">Contact</a>
                  </li>
                  <li className="nav-item px-2">
                    <a className="nav-link add-to-cart-button" href="/cart"><i className="fa-solid fa-cart-shopping" style={{ color: '#f8f4f4' }}></i></a>
                  </li>
                </ul>
                <form className="d-flex" role="search">
                  <input className="form-control rounded-5 me-2" type="search" placeholder="Search" aria-label="Search" />
                  <button className="btn btn-warning rounded-5" type="submit">Search</button>
                </form>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </>
  )
}

export default Header