import React from 'react'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Layout from './Component/Layout' 
import Home from './Component/Pages/home/Home'
import About from './Component/Pages/About/about'
import Header from './Component/Header';
import Footer from './Component/Footer';
import Login from './Component/Pages/Login/login';
import Register from './Component/Pages/Register/register';
import Contact from './Component/Pages/Contact/contact';
import Cart from './Component/Pages/Cart/cart';


const App = () => {
  return (
    <>
     <Router>
     <Header />
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/cart" element={<Cart />} />
          </Routes>
        </Layout>
        <Footer />
     </Router>
      
      
    </>
  )
}

export default App